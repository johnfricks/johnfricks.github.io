#' Particle filter
#'
#' Runs the particle filter for the E step of the stochastic EM algorithm.
#'
#' Resample particles using multinomial sampling at each time step so w.k^r <- 1/numParts.
#'
#' Particle filter implemented \code{numParts/SSR} times in parallel with \code{SSR} particles in each run.
#'
#' @param Yt Trajectory.  Matrix with N rows and 2 columns.
#' @param nu Drift term
#' @param sig1 Standard deviation of bound regime
#' @param sig2 Standard deviation of unbound regime
#' @param phi Discrete-time autoregressive parameter
#' @param Gamma Transition probability matrix
#' @param eta Standard deviation of Gaussian observational error
#' @param numParts Number of particles, or M.
#' @param SSR Number of particles in each strata of the particle filter.
#' @param Q Size of smoothing window, described in the pseudocode.
#' @param osa logical: if \code{TRUE} then compute the standardized, one-step ahead prediction residuals under the provided parameters.
#' If \code{FALSE}, the particle filter and smooth is implemented.
#' @return If \code{osa=TRUE}, a list of N-by-M matrices of particles approximating the distribution of the unobserved
#'  states given the observations is returned.  In particular, the following items are returned:
#' \itemize{
#'  \item \code{j.t} Particle approximation of p(j_t|Y_{0:N}).
#'  \item \code{j.tmin1} Particles approximation of p(jt-1|Y_{0:N}).
#'  \item \code{z1.t} Particle approximation of p(z^1_t|Y_{0:N}).
#'  \item \code{z2.t} Particle approximation of p(z^2_t|Y_{0:N}).
#'  \item \code{z1.tmin1} Particle approximation of p(z^1_{t-1}|Y_{0:N}).
#'  \item \code{z2.tmin1} Particle approximation of p(z^2_{t-1}|Y_{0:N}).
#'  \item \code{z1.t.tau} Particle approximation of p(z^1_tau_t|Y_{0:N}).
#'  \item \code{z2.t.tau} Particle approximation of p(z^2_tau_t|Y_{0:N}).
#'  \item \code{llik} Estimate of log-likelihood.
#' }
#' If \code{osa=FALSE}, a list is returned containing the following items:
#' \itemize{
#'  \item \code{filterJt} Filter distribution p(jt|Y_{0:N}).
#'  \item \code{filterZt} Filter distribution p(zt|Y_{0:N}).
#'  \item \code{osa.mean} Mean of the one-step ahead prediction distribution p(z_k|Y_{0:k-1}).
#'  \item \code{std.pred.res} Standardized prediction residuals.
#'  \item \code{llik} Estimate of log-likelihood.
#' }
#' @examples
#' # Set continuous-time model parameters
#' lenPath <- 500
#' Dt      <- 1/1000
#' mu      <- c(0,0.1)
#' D1      <- 0.03
#' D2      <- 0.08
#' phi     <- 0.3
#' Gamma   <- matrix(c(0.95,0.05,0.05,0.95),2)
#' eta     <- sqrt(2*D1*Dt)
#'
#' # Simulate trajectory
#' set.seed(12345)
#' paths <- simPath(lenPath,Dt,mu,D1,D2,phi,Gamma,eta)
#' Yt    <- paths$Yt
#'
#' # Set tuning parameters for particle filter
#' numParts <- 1000 #  Number of particles
#' SSR      <- 500   # Number of particles to run in each strata of filter
#' Q        <- 5     # Fixed-lag window size
#' osa      <- FALSE # Whether to produce one-step ahead predictors or not
#' # Discrete-time model parameters
#' nu       <- c(0,0)
#' sig1     <- sqrt(2*D1*Dt)
#' sig2     <- sqrt(2*D2*Dt)
#'
#' # Run particle filter
#' pf.run   <- particle_filter(Yt,nu,sig1,sig2,phi,Gamma,eta,numParts,SSR,Q,osa)
#'
#' # Plot true regime and particle prediction
#' par(mfrow=c(1,2))
#' plot.ts(paths$Jt,ylim=c(0,2))
#' smoothJt        <- matrix(NA,nrow=length(Yt[,1]),ncol=2)
#' for(i in 1:2){smoothJt[,i] <- apply(pf.run$j.t,1,function(k) mean(k==i))}
#' lines(smoothJt[,2],col=2)
#'
#' # Plot marginal position of particle over time and overlay particle prediction
#' plot.ts(paths$Yt[,1])
#' lines(apply(pf.run$z1.t,1,mean),col=2)

particle_filter = function(Yt,nu,sig1,sig2,phi,Gamma,eta,numParts,SSR,Q,osa)
{
  lenPath     <- length(Yt[,1]) # = N+1 in our notation
  m           <- length(diag(Gamma))
  starts      <- seq(1,numParts,by=SSR)
  ends        <- seq(SSR,numParts,by=SSR)
  llik        <- 0
  # Obtain stationary distribution of MC
  p0          <- solve(t(diag(m)-Gamma+1),rep(1,m))
  # Pre-allocate space to store particles, one-step ahead predictors, and filter means
  w.tmin1     <- rep(1/SSR,numParts)
  j.t         <- j.tmin1  <- matrix(NA,nrow=lenPath,ncol=numParts)
  z1.t        <- z2.t     <- matrix(NA,nrow=lenPath,ncol=numParts)
  z1.tmin1    <- z2.tmin1 <- matrix(NA,nrow=lenPath,ncol=numParts)
  z1.t.tau    <- z2.t.tau <- matrix(NA,nrow=lenPath,ncol=numParts)
  osa.mean    <- osa.var  <- matrix(NA,nrow=lenPath,ncol=2)
  filterJt    <- filterZt <- matrix(NA,nrow=lenPath,ncol=2)
  # Initialisation - t = 0
  # ... initialize regime
  j.tmin1[1,] <- j.t[1,] <- sample(x=1:m,size=numParts,replace=TRUE,prob=p0)
  # ... initialize current and most recent position and binding site
  z1.t[1,]     <- rnorm(numParts,0,sd=eta)
  z2.t[1,]     <- rnorm(numParts,0,sd=eta)
  z1.t.tau[1,] <- z1.tmin1[1,] <- z1.t[1,]
  z2.t.tau[1,] <- z2.tmin1[1,] <- z2.t[1,]
  # Perform particle filtering
  for (t.ind in 2:lenPath) {
    if(t.ind %% 500 == 0){print(paste("Made it to time",t.ind))}
    # Update particles at time t-1
    z1.tmin1[t.ind,]         <- z1.t[t.ind-1,]
    z2.tmin1[t.ind,]         <- z2.t[t.ind-1,]
    j.tmin1[t.ind,]          <- j.t[t.ind-1,]
    # Update binding sites
    tau.ind1                 <- which(j.tmin1[t.ind,]==1)
    tau.ind2                 <- which(j.tmin1[t.ind,]==2)
    z1.t.tau[t.ind,tau.ind1] <- z1.t.tau[t.ind-1,tau.ind1]
    z2.t.tau[t.ind,tau.ind1] <- z2.t.tau[t.ind-1,tau.ind1]
    z1.t.tau[t.ind,tau.ind2] <- z1.tmin1[t.ind,tau.ind2]
    z2.t.tau[t.ind,tau.ind2] <- z2.tmin1[t.ind,tau.ind2]
    # Propose particles from state transition density
    # Propose regime
    for(i in 1:m){ind    <- which(j.tmin1[t.ind,]==i)
    j.t[t.ind,ind] <- sample(1:m,size=length(ind),replace=TRUE,prob=Gamma[i,])}
    # Propose position...
    # ... in bound state
    ind             <- which(j.t[t.ind,]==1)
    z1.t[t.ind,ind] <- (1-phi)*z1.t.tau[t.ind,ind]+phi*z1.tmin1[t.ind,ind]+sig1*rnorm(length(ind))
    z2.t[t.ind,ind] <- (1-phi)*z2.t.tau[t.ind,ind]+phi*z2.tmin1[t.ind,ind]+sig1*rnorm(length(ind))
    # ... in unbound state
    ind             <- which(j.t[t.ind,]==2)
    z1.t[t.ind,ind] <- z1.tmin1[t.ind,ind]+nu[1]+sig2*rnorm(length(ind))
    z2.t[t.ind,ind] <- z2.tmin1[t.ind,ind]+nu[2]+sig2*rnorm(length(ind))
    # Compute unnormalized importance weights
    w.t <- dnorm(x=Yt[t.ind,1],mean=z1.t[t.ind,],sd=eta)*dnorm(Yt[t.ind,2],z2.t[t.ind,],eta)
    # Compute one-step ahead (OSA) predictors
    if(osa == TRUE){
      # Compute filter for position and regime
      filterJt[t.ind,] <- c(sum(w.t[j.t[t.ind,]==1]),sum(w.t[j.t[t.ind,]==2]))/sum(w.t)
      filterZt[t.ind,] <- c(sum(w.t*z1.t[t.ind,]),sum(w.t*z2.t[t.ind,]))/sum(w.t)
      # Compute one-step ahead predictors
      y1.t             <- rnorm(numParts,z1.t[t.ind,],eta)
      y2.t             <- rnorm(numParts,z2.t[t.ind,],eta)
      # Compute one-step ahead mean and variance
      osa.mean[t.ind,] <- c(mean(y1.t),mean(y2.t))
      osa.var[t.ind,]  <- c(mean((y1.t-osa.mean[t.ind,1])^2),mean((y2.t-osa.mean[t.ind,2])^2))
    }
    # Add contribution to log-likelihood
    llik    <- llik + log(sum(w.t)/(numParts/SSR)) # Unnormalized is important here
    # Resample particles
    windInd <- max(1,t.ind-Q) # If windInd>lenPath, then swap entire path
    swapInd <- windInd:t.ind
    for(i in 1:length(starts)){
      strata      <- starts[i]:ends[i]
      # Resample particles according to their weights.  w.t automatically noramlized.
      selInd                    <- sample(x=strata,size=SSR,replace=TRUE,prob=w.t[strata])
      j.t[swapInd,strata]       <- j.t[swapInd,selInd]
      j.tmin1[swapInd,strata]   <- j.tmin1[swapInd,selInd]
      z1.t[swapInd,strata]      <- z1.t[swapInd,selInd]
      z2.t[swapInd,strata]      <- z2.t[swapInd,selInd]
      z1.tmin1[swapInd,strata]  <- z1.tmin1[swapInd,selInd]
      z2.tmin1[swapInd,strata]  <- z2.tmin1[swapInd,selInd]
      z1.t.tau[swapInd,strata]  <- z1.t.tau[swapInd,selInd]
      z2.t.tau[swapInd,strata]  <- z2.t.tau[swapInd,selInd]
    }
    # Reset particle weights to w.t[strata] <- w.tmin1 <- 1/SSR
    # ...
    # Set t <- t + 1 and start over
  }
  # Compute standardized prediction residuals
  std.pred.res <- (Yt - osa.mean)/sqrt(osa.var)
  # Output sample paths
  if(osa == FALSE){
    list(j.t=j.t,j.tmin1=j.tmin1,z1.t=z1.t,z2.t=z2.t,z1.tmin1=z1.tmin1,z2.tmin1=z2.tmin1
         ,z1.t.tau=z1.t.tau,z2.t.tau=z2.t.tau,llik=llik)} else {
    list(filterJt=filterJt,filterZt=filterZt,osa.mean=osa.mean,std.pred.res=std.pred.res,llik=llik)}
}
