#' Compute observed information matrix
#'
#' Computes particle approximation to the observed information matrix.
#'
#' @param Yt Trajectory.
#' @param particles Particles from the E step.
#' @param Gamma Transition probability matrix.
#' @param sig1 Standard deviation in bound regime.
#' @param sig2 Standard deviation in unbound regime.
#' @param phi Discrete-time autoregressive parameter.
#' @param eta Standard deviation of observational error.
#' @return A list containing the following items:
#' \itemize{
#'   \item \code{OIM} Estimate of observed information matrix.
#'   \item \code{var.cov.est} Estimate of variance-covariance matrix.
#' }
#' @examples
#' # Test code on simulated data
#' set.seed(6)
#' # Set model parameters
#' D1       <- 0.4
#' D2       <- 0.85
#' Dt       <- 1/1000
#' mu       <- c(0,0)
#' phi      <- 0.25
#' p12      <- 0.025
#' p21      <- 0.08
#' Gamma    <- matrix(c(1-p12,p21,p12,1-p21),2)
#' pStall   <- solve(t(diag(2)-Gamma+1),rep(1,2))[1]
#' eta      <- sqrt(2*D1*Dt)/sqrt(1-phi^2)
#' lenPath  <- 501
#'
#' # Simulate path
#' pathOrig <- simPath(lenPath,Dt,mu,D1,D2,phi,Gamma,eta)
#' Zt       <- pathOrig$Zt; Jt <- pathOrig$Jt; Yt <- pathOrig$Yt
#'
#' # Estimation parameters
#' numParts  <- rep(500,1)
#' SSR       <- 500
#' estExpErr <- TRUE
#' estMu     <- TRUE
#' Q         <- 3
#'
#' # Fit the path
#' nu     <- c(0,0)
#' sig1   <- sqrt(2*D1*Dt)
#' sig2   <- sqrt(2*D2*Dt)
#' result <- stochastic_EM(Yt=Yt,nu=nu,phi=phi,sig1=sig1,sig2=sig2
#'                       ,Gamma=Gamma,eta=eta,numParts=numParts,SSR=SSR,Q=Q)
#'
#' # Get particles
#' particles  <- particle_filter(Yt,result$nu,result$sig1,result$sig2,result$phi
#'                              ,result$Gamma,result$eta,numParts,SSR,Q,osa=FALSE)
#'
#' # Compute Observed Information Matrix
#' est.OIM <- compute_OIM(Yt,particles,result$Gamma,result$nu,result$sig1,result$sig2,result$phi,result$eta)
#'
#' # Is the estimate of the variance-covariance matrix positive-definite?
#' # Check by determining if all diagonal elements are positive.
#' all(diag(est.OIM$var.cov.est)>0)

compute_OIM = function(Yt,particles,Gamma,nu,sig1,sig2,phi,eta){

  # Extract particles
  j.t         <- particles$j.t
  j.tmin1     <- particles$j.tmin1
  z1.t        <- particles$z1.t
  z2.t        <- particles$z2.t
  z1.t.tau    <- particles$z1.t.tau
  z2.t.tau    <- particles$z2.t.tau
  z1.tmin1    <- particles$z1.tmin1
  z2.tmin1    <- particles$z2.tmin1

  # Pull out needed values
  lenPath   <- length(Yt[,1])
  numParts  <- length(j.t[1,])

  ##############################################################
  # Compute score vector:   \nabla \ell_{X^r,Y}(\Theta)
  scores    <- list()
  # Compute estimate of score for each particle
  for(i in 1:numParts){
    # Pre-allocate space to store results
    score     <- rep(NA,6)
    # Score for transition probabilities
    score[1]  <- sum((j.tmin1[,i]==1)*(j.t[,i]==1))/Gamma[1,1]-sum((j.tmin1[,i]==1)*(j.t[,i]==2))/(1-Gamma[1,1])
    score[2]  <- sum((j.tmin1[,i]==2)*(j.t[,i]==2))/Gamma[2,2]-sum((j.tmin1[,i]==2)*(j.t[,i]==1))/(1-Gamma[2,2])
    # Score for sig1.sq
    score[3]  <- sum(j.t[,i]==1)/sig1^2 +
      sum((z1.t[,i]-z1.t.tau[,i]-phi*(z1.tmin1[,i]-z1.t.tau[,i]))^2*(j.t[,i]==1))/2/sig1^4+
      sum((z2.t[,i]-z2.t.tau[,i]-phi*(z2.tmin1[,i]-z2.t.tau[,i]))^2*(j.t[,i]==1))/2/sig1^4
    # Score for sig2.sq
    score[4]  <- sum(j.t[,i]==2)/sig2^2+
      sum((z1.t[,i]-z1.tmin1[,i]-nu[1])^2*(j.t[,i]==2))/2/sig2^4+
      sum((z2.t[,i]-z2.tmin1[,i]-nu[2])^2*(j.t[,i]==2))/2/sig2^4
    # Score for phi
    score[5]  <- sum((z1.tmin1[,i]-z1.t.tau[,i])*(z1.t[,i]-z1.t.tau[,i]-phi*(z1.tmin1[,i]-z1.t.tau[,i]))*(j.t[,i]==1))/2/sig1^2 +
      sum((z2.tmin1[,i]-z2.t.tau[,i])*(z2.t[,i]-z2.t.tau[,i]-phi*(z2.tmin1[,i]-z2.t.tau[,i]))*(j.t[,i]==1))/2/sig1^2
    # Score for eta
    score[6]  <- sum(j.t[,i]==1)/eta^2 + sum((Yt[,1]-z1.t[,i])^2)/2/eta^4 + sum((Yt[,2]-z2.t[,i])^2)/2/eta^4
    # Save score for ith particle
    scores[[i]] <- score
  }

  ##############################################################
  # Compute matrix of second derivatives:   \nabla^2 \ell_{X^r,Y}(\Theta)
  nabla.sqs     <- list()
  # Compute nabla.sq for each particle
  for(i in 1:numParts){
    nabla.sq      <- matrix(0,nrow=6,ncol=6)
    # nabla.sq for gamma.ii
    nabla.sq[1,1] <- sum(-(j.tmin1[,i]==1)*(j.t[,i]==1))/Gamma[1,1]^2-sum((j.tmin1[,i]==1)*(j.t[,i]==2))/(1-Gamma[1,1])^2
    nabla.sq[2,2] <- sum(-(j.tmin1[,i]==2)*(j.t[,i]==2))/Gamma[2,2]^2-sum((j.tmin1[,i]==2)*(j.t[,i]==1))/(1-Gamma[2,2])^2
    # nabla.sq for sig1.sq
    nabla.sq[3,3] <- sum(j.t[,i]==1)/(sig1^2)^2 +
      sum((z1.t[,i]-z1.t.tau[,i]-phi*(z1.tmin1[,i]-z1.t.tau[,i]))^2*(j.t[,i]==1))/2/sig1^6+
      sum((z2.t[,i]-z2.t.tau[,i]-phi*(z2.tmin1[,i]-z2.t.tau[,i]))^2*(j.t[,i]==1))/2/sig1^6
    # nabla.sq for sig2.sq
    nabla.sq[4,4] <- sum(j.t[,i]==2)/(sig2^2)^2 +
      sum((z1.t[,i]-z1.tmin1[,i]-nu[1])^2*(j.t[,i]==2))/2/sig2^6 +
      sum((z2.t[,i]-z2.tmin1[,i]-nu[2])^2*(j.t[,i]==2))/2/sig2^6
    # nabla.sq for phi
    nabla.sq[5,5] <- -sum((z1.tmin1[,i]-z1.t.tau[,i])^2*(j.t[,i]==1))/2/sig1^2 -
      sum((z2.tmin1[,i]-z2.t.tau[,i])^2*(j.t[,i]==1))/2/sig1^2
    # nabla.sq for eta
    nabla.sq[6,6] <- sum(j.t[,i]==1)/eta^4 + sum((Yt[,1]-z1.t[,i])^2)/2/eta^6 + sum((Yt[,2]-z2.t[,i])^2)/2/eta^6
    # nabla.sq for the cross-term
    nabla.sq[5,3] <- nabla.sq[3,5] <- sum((z1.tmin1[,i]-z1.t.tau[,i])*(z1.t[,i]-z1.t.tau[,i]-phi*(z1.tmin1[,i]-z1.t.tau[,i]))^2*(j.t[,i]==1))/2/sig1^4 +
      sum((z2.tmin1[,i]-z2.t.tau[,i])*(z2.t[,i]-z2.t.tau[,i]-phi*(z2.tmin1[,i]-z2.t.tau[,i]))^2*(j.t[,i]==1))/2/sig1^4
    # Save nabla for the ith particle
    nabla.sqs[[i]] <- nabla.sq
  }

  ##############################################################
  # Put the three terms together with the score and nabla.sq to get the observed information matrix (OIM)
  term1         <- Reduce(f='+',x=scores) %*% t(Reduce(f='+',x=scores))/numParts^2
  term2         <- matrix(0,6,6); for(i in 1:numParts){term2 <- term2 + scores[[i]]%*%t(scores[[i]])}; term2 <- term2/numParts
  term3         <- matrix(0,6,6); for(i in 1:numParts){term3 <- term3 + nabla.sqs[[i]]%*%t(nabla.sqs[[i]])}; term3 <- term3/numParts
  OIM           <- term1 - term2 - term3

  # Estimate of variance-covariance matrix is inverse of OIM
  var.cov.est   <- solve(OIM)

  # Return
  list(OIM=OIM,var.cov.est=var.cov.est)

}
