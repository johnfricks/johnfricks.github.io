#' Stochastic EM Algorithm
#'
#' Implement stochastic EM algorithm in Bernstein and Fricks (2015).
#'
#' @param Yt Trajectory, provided as a matrix with lenPath rows and two columns.
#' @param Dt Sampling rate, or Delta.
#' @param nu Initial estimate of drift term.
#' @param phi Initial estimate of the discrete-time autoregressive parameter
#' @param sig1 Initial estimate of the standard deviation of the bound regime.
#' @param sig2 Initial estimate of the standard deviation of the unbound regime.
#' @param Gamma Initial estimate of the transition probability matrix.
#' @param eta Initial estimate of standard deviation of observational error.
#' @param numParts Vector whose ith element is the number of particles to run in the particle filter at the ith iteration.
#' @param SSR Number of particles in each parallel run of the filter.
#' @param Q Size of smoothing window, described in the pseudocode.
#' @return A list with components:
#' \itemize{
#'  \item \code{Yt} Fitted trajectory.
#'  \item \code{time.elap} Elapsed time.
#'  \item \code{numIter} Number of EM iterations.
#'  \item \code{sig1} Final estimate of \eqn{\sigma_1}.
#'  \item \code{sig2} Final estimate of \eqn{\sigma_2}.
#'  \item \code{nu} Final estimate of \eqn{\nu}.
#'  \item \code{phi} Final estimate of \eqn{\phi}.
#'  \item \code{Gamma} Final estimate of \eqn{\Gamma}.
#'  \item \code{eta} Final estimate of \eqn{\eta}.
#'  \item \code{statn.distn} Stationary distribution of the fitted Markov chain.
#'  \item \code{smoothJt} Computed smooth distribution \eqn{p(j_k|Y_{0:N})}.
#'  \item \code{smoothZt} Computed smooth distribution \eqn{p(z_k|Y_{0:N})}.
#'  \item \code{filterJt} Computed filter distribution \eqn{p(j_k|Y_{0:k})}.
#'  \item \code{filterZt} Computed filter distribution \eqn{p(z_k|Y_{0:k})}.
#'  \item \code{std.pred.res} Standardized prediction residuals.
#'  \item \code{History} Iterates of the estimated parameters and log-likelihood.
#'  \item \code{Q} See above.
#' }
#' @examples
#' # Set parameters for simulating a trajectory
#' lenPath <- 500
#' Dt      <- 1/1000
#' mu      <- c(0,0.1)
#' D1      <- 0.03
#' D2      <- 0.08
#' phi     <- 0.3
#' Gamma   <- matrix(c(0.95,0.05,0.05,0.95),2)
#' eta     <- sqrt(2*D1*Dt)
#'
#' # Simulate trajectory
#' set.seed(12345)
#' paths <- simPath(lenPath,Dt,mu,D1,D2,phi,Gamma,eta)
#' Yt    <- paths$Yt
#'
#' # Set parameters for particle filter
#' numParts <- c(rep(500,2),1000) #  Number of particles
#' SSR      <- 500   # Number of particles to run in each strata of filter
#' Q        <- 5     # Fixed-lag window size
#' osa      <- FALSE # Whether to produce one-step ahead predictors or not
#'
#' # Set initial starting values
#' nu     <- c(0,0)
#' phi0   <- 0.3
#' sig1   <- sqrt(2*D1*Dt)
#' sig2   <- sqrt(2*D2*Dt)
#'
#' # Implement stochastic EM algorithm
#' sem <- stochastic_EM(Yt,nu,phi,sig1,sig2,Gamma,eta,numParts,SSR,Q)
#'
#' # Plot convergence of parameter estimates across iterations
#' plot.ts(sem$H)

stochastic_EM = function(Yt,nu,phi,sig1,sig2,Gamma,eta,numParts,SSR,Q)
{
  # Record initial time
  time.init <- proc.time()[3]
  # Number of iterations
  maxit     <- length(numParts)
  # Number of states
  m         <- length(diag(Gamma))
  # Pre-allocate space to store log-likelihoods
  lliks     <- rep(NA,maxit)
  # Start recording the history
  History   <- c(nu,phi,sig1,sig2,diag(Gamma),eta)
  print(History)

  # Check for potential problems
  if(any(numParts %% SSR != 0)) stop("Mismatch between number of particles and stratified sampling parameter.")
  if(Yt[1,1] !=0 | Yt[1,2] != 0)stop("Initial positions are not equal to zero.")

  # Obtain initial distribution, assume same as stationary distribution
  p0     <- solve(t(diag(m)-Gamma+1),rep(1,m))

  # Run through EM iterations
  for (iter in 1:maxit){

    # Print progress
    print(paste("Starting iteration",iter))

    # Perform E-step
    #  Get smoother approx. of p(j_{0:N},z_{0:N}|Y_{0:N})
    E_step      <- particle_filter(Yt=Yt,nu=nu,sig1=sig1,sig2=sig2,phi=phi,Gamma=Gamma,eta=eta
                               ,numParts=numParts[iter],SSR=SSR,Q=Q,osa=FALSE)
    lliks[iter] <- E_step$llik # Filter log-likelihood
    # Print progress
    print("Finished E step")

    # Perform M-step
    M_step     <- update_params(Yt=Yt,particles=E_step)
    nu         <- M_step$nu.next
    phi        <- M_step$phi.next
    sig1       <- M_step$sig1.next
    sig2       <- M_step$sig2.next
    eta        <- M_step$eta.next
    Gamma      <- M_step$Gamma.next
    # Print progress
    print("Finished M step")

    # Print current parameter estimates
    print(c(nu,phi,sig1,sig2,diag(Gamma),eta))
    # Save parameter updates
    History    <- rbind(History,c(nu,phi,sig1,sig2,diag(Gamma),eta))

    # Print progess
    print(paste("Finished iteration",iter))

  } # End EM iterations

  # Compute stationary distribution of Markov chain
  statn.distn <- solve(t(diag(m)-Gamma+1),rep(1,m))

  # Obtain smooth densities...
  # ...of Zt
  smoothZt        <- cbind(rowMeans(E_step$z1.t),rowMeans(E_step$z2.t))
  # smoothResiduals <- Yt - smoothZt # Observed minus fitted
  # ...of Jt
  smoothJt        <- matrix(NA,nrow=length(Yt[,1]),ncol=m)
  for(i in 1:m){smoothJt[,i] <- apply(E_step$j.t,1,function(k) mean(k==i))}

  # Obtain filter density, one-step ahead predictors, etc.
  # tryCatch(..., error=function(e) NULL)
  osa            <- particle_filter(Yt=Yt,nu=nu,sig1=sig1,sig2=sig2,phi=phi,Gamma=Gamma,eta=eta
                                ,numParts=numParts[iter],SSR=SSR,Q=Q,osa=TRUE)
  std.pred.res   <- osa$std.pred.res[-1,]
  filterJt       <- osa$filterJt
  filterZt       <- osa$filterZt
  lliks[maxit+1] <- osa$llik
  # Print progress
  print("Finished OSA step")

  # Put column names on History matrix
  History           <- cbind(History,lliks)
  colnames(History) <- c("nu1","nu2","phi","sig1","sig2","gamma11","gamma22","Exp. Error","log-like")

  # Record final time (minutes)
  time.elap <- (proc.time()[3]-time.init)/60

  # Return final parameter estimates, smooth densities, likelihoods, etc.
  list(Yt=Yt,time.elap=time.elap,numIter=maxit
       ,sig1=sig1,sig2=sig2,nu=nu,phi=phi,Gamma=Gamma,eta=eta,statn.distn=statn.distn
       ,smoothJt=smoothJt,smoothZt=smoothZt,filterJt=filterJt,filterZt=filterZt
       ,std.pred.res=std.pred.res,History=History,Q=Q)
}
