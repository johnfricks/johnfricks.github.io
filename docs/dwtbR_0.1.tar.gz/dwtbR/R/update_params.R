#' M step
#'
#' Updates parameters for the M step of the stochastic EM algorithm.
#'
#' @param Yt The trajectory Y_{0:N}.
#' @param particles Particles used to update the parameters.
#' @return Updated estimates of the parameters.
#' @examples
#' # Set parameters of continuous-time model
#' lenPath <- 500
#' Dt      <- 1/1000
#' mu      <- c(0,0.1)
#' D1      <- 0.03
#' D2      <- 0.08
#' phi     <- 0.3
#' Gamma   <- matrix(c(0.95,0.05,0.05,0.95),2)
#' eta     <- sqrt(2*D1*Dt)
#'
#' # Simulate trajectory of continuous-time, physical model
#' set.seed(12345)
#' paths <- simPath(lenPath,Dt,mu,D1,D2,phi,Gamma,eta)
#' # Pull out observed trajectory
#' Yt    <- paths$Yt
#'
#' # Implement particle filter
#' numParts <- 1000 # Number of particles
#' SSR      <- 500  # Strata of particle filter
#' Q        <- 4
#' osa      <- FALSE
#' nu       <- c(0,0)
#' sig1     <- sqrt(2*D1*Dt)
#' sig2     <- sqrt(2*D2*Dt)
#' pf.run   <- particle_filter(Yt,nu,sig1,sig2,phi,Gamma,eta,numParts,SSR,Q,osa)
#'
#' # Get parameter updates in M step
#' M_step   <- update_params(Yt,pf.run)
#' M_step

update_params = function(Yt,particles) {
  # Extract particles
  j.t         <- particles$j.t[-1,]
  j.tmin1     <- particles$j.tmin1[-1,]
  z1.t        <- particles$z1.t[-1,]
  z2.t        <- particles$z2.t[-1,]
  z1.t.tau    <- particles$z1.t.tau[-1,]
  z2.t.tau    <- particles$z2.t.tau[-1,]
  z1.tmin1    <- particles$z1.tmin1[-1,]
  z2.tmin1    <- particles$z2.tmin1[-1,]
  # Initialise
  Yt          <- Yt
  lenPath     <- length(Yt[,1])
  numParts    <- length(j.t[1,])
  ###############################################################
  # Update Gamma
  # Compute f_ij for i,j=0,1 --- sums number of transitions amongst the particles
  f.mat 	  	<- matrix(0,2,2)
  f.mat[1,1] <- sum((j.tmin1==1)*(j.t==1))
  f.mat[1,2] <- sum((j.tmin1==1)*(j.t==2))
  f.mat[2,1] <- sum((j.tmin1==2)*(j.t==1))
  f.mat[2,2] <- sum((j.tmin1==2)*(j.t==2))
  # Output Gamma
  Gamma.next <- f.mat/rowSums(f.mat)
  ###############################################################
  # Update nu
  dZ1t      <- z1.t - z1.tmin1
  dZ2t      <- z2.t - z2.tmin1
  mean.dZ1t <- mean(dZ1t[j.t==2])
  mean.dZ2t <- mean(dZ2t[j.t==2])
  nu.next   <- c(mean.dZ1t,mean.dZ2t)
  ###############################################################
  # Update phi
  top.sum   <- sum(((z1.t-z1.t.tau)*(z1.tmin1-z1.t.tau))[j.t == 1] + ((z2.t-z2.t.tau)*(z2.tmin1-z2.t.tau))[j.t == 1])
  bot.sum   <- sum(((z1.tmin1-z1.t.tau)^2+(z2.tmin1-z2.t.tau)^2)[j.t == 1])
  phi.next  <- top.sum/bot.sum
  ###############################################################
  # Update Diffusion coefficients
  # ... bound state
  sig1.next <- sqrt(mean((z1.t-(1-phi.next)*z1.t.tau-phi.next*z1.tmin1)[j.t == 1]^2 +
                         (z2.t-(1-phi.next)*z2.t.tau-phi.next*z2.tmin1)[j.t == 1]^2)/2)
  # ... diffusive state
  dZ1tNu    <- dZ1t-nu.next[1] # Update with new estimates of nu
  dZ2tNu    <- dZ2t-nu.next[2]
  sig2.next <- sqrt(mean((dZ1tNu^2+dZ2tNu^2)[j.t==2])/2)
  #################################################################
  # Estimate experimental error
  eta.next  <- sqrt( mean((particles$z1.t-Yt[,1])^2+(particles$z2.t-Yt[,2])^2)/2 )
  #################################################################
  # Return updated parameter estimates
  list(Gamma.next=Gamma.next,nu.next=nu.next,phi.next=phi.next
       ,sig1.next=sig1.next,sig2.next=sig2.next,eta.next=eta.next)
}
