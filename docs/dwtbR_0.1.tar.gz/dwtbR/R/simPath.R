#' Simulate trajectory
#'
#' Simulates a trajectory of the diffusion with transient binding model.
#'
#' @param lenPath Length of path to simulate.
#' @param Dt Sampling rate, or Delta.
#' @param mu Drift term.
#' @param D1 Diffusion coefficient in the bound regime.
#' @param D2 Diffusion coefficient in the unbound regime.
#' @param phi Discrete-time autoregressive parameter.
#' @param Gamma Transition probability matrix.
#' @param eta Standard deviation of Gaussian observational error
#' @return A list containing the following objects:
#' \itemize{
#'   \item \code{Yt} Observed positions Y_{0:N}.
#'   \item \code{Xt} Unoberved positions X_{0:N}.
#'   \item \code{Jt} Regimes J_{0:N}.
#' }
#' @examples
#' # Set parameters
#' lenPath <- 500
#' Dt      <- 1/1000
#' mu      <- c(0,0.1)
#' D1      <- 0.03
#' D2      <- 0.08
#' phi     <- 0.3
#' Gamma   <- matrix(c(0.95,0.05,0.05,0.95),2)
#' eta     <- sqrt(2*D1*Dt)
#'
#' # Simulate path
#' set.seed(12345)
#' paths <- simPath(lenPath,Dt,mu,D1,D2,phi,Gamma,eta)
#'
#' # Plot paths
#' par(mfrow=c(1,3))
#' # Plot regime sequence
#' plot.ts(paths$Jt)
#' # Plot position of particle over time
#' plot(paths$Zt[,1],paths$Zt[,2],type="l")
#' # Plot marginal position of particle over time
#' plot.ts(paths$Yt[,1])

simPath = function(lenPath,Dt,mu,D1,D2,phi,Gamma,eta){
  N        <- lenPath - 1
  lambdas  <- -diag(logm(Gamma))/Dt
  kappa    <- -log(phi)/Dt
  m     <- length(diag(Gamma))
  # Determine stationary distribution
  p0    <- solve(t(diag(m)-Gamma+1),rep(1,m))
  # Draw initial state from stationary distribution
  init.state <- sample(x=1:m,size=1,prob=p0)
  # Simulate continuous-time Markov chain past length of chain
  states         <- init.state                        # Initial state
  rgm.swt.times  <- rexp(1,rate=lambdas[init.state]) # Time in initial state
  count          <- 1
  while(sum(rgm.swt.times) <= lenPath*Dt){
    if(states[count] == 1){states <- c(states,2); rgm.swt.times <- c(rgm.swt.times,rexp(1,rate=lambdas[2]))} else {
                           states <- c(states,1); rgm.swt.times <- c(rgm.swt.times,rexp(1,rate=lambdas[1]))}
    count <- count + 1
  }
  # Draw states 2:lenPath for discrete-time Markov chain
  rgm.swt.times <- cumsum(rgm.swt.times)
  # Times to evaluate regime chain at
  obs.times     <- (0:lenPath)*Dt
  # Simulate unobserved Markov chain
  # Pre-allocate space to store MC
  Jt            <- rep(NA,lenPath)
  Jt[1]         <- init.state # State at time 0
  for(i in 2:lenPath){   Jt[i] <- states[which.min(Dt*(i-1) >= rgm.swt.times)] }
  # Initialize \tau_t
  Zt.tau        <- c(0,0)
  # Times to evaluate position at
  evalTimes     <- sort(unique(c((0:lenPath)*Dt,rgm.swt.times[1:(length(rgm.swt.times)-1)])))
  Zt            <- matrix(NA,nrow=length(evalTimes),ncol=2)
  Zt[1,]        <- 0
  Jt.orig       <- Jt[1]
  for(i in 2:length(evalTimes)){
    # What state are you currenty in?
    stt     <- states[which.min(evalTimes[i] >= rgm.swt.times)]
    Delta   <- evalTimes[i]-evalTimes[i-1]
    # Bound regime (Diffusion in a quadratic potential)
    phi     <-  exp(-kappa*Delta)
    if(stt==1){Zt[i,] <- (1-phi)*Zt.tau+phi*Zt[i-1,]+sqrt(2*D1*(1-phi^2)/(2*kappa))*rnorm(2)
    Jt.orig <- c(Jt.orig,1)}
    # Unbound regime (free Brownian diffusion)
    if(stt==2){Zt[i,] <- Zt[i-1,]+mu*Delta+sqrt(2*D2*Delta)*rnorm(2)
              Jt.orig <- c(Jt.orig,2)
              # Update binding site
              Zt.tau <- Zt[i,]}
  }
  # Extract Zt at times of observation
  Zt.orig <- Zt
  ind     <- which(evalTimes %in% obs.times)
  Zt      <- Zt[ind,]
  # Add experimental error
  Yt      <- Zt + eta*matrix(rnorm(length(Zt)),nrow=length(Zt[,1]),ncol=2)
  Yt[1,]  <- 0
  # Return unobserved and observed processes
  list(Jt=Jt,Zt=Zt,Yt=Yt)
}
